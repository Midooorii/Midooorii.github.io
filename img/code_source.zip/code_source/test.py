

import mygraph as gr
from random import *
import pile as Pile
from itertools import combinations


graph={"A" : ["C"],
       "B" : ["C", "E"],
       "C" : ["A", "B", "D", "E"],
       "D" : ["C","F"],
       "E" : ["C", "B","F"],
       "F" : ["E","D"]
      }

#print(graph["A"])
graph2=gr.Graphe2(graph)

def parcours_profondeur(g: dict, depart: str, visites=None)->list:
    # pour le premier appel avec la liste vide
    if visites is None:
        visites = [depart]
    else:
        # marquer s comme visté
        visites.append(depart)
    
    for voisin in g[depart]:
        if voisin not in visites:
            parcours_profondeur(g, voisin, visites)
    return visites


def plusCourtChemin(Graph , start, dest):
    parents = {start: None}
    file = []
    file.append(start)
    visites = [start]
    while file:
        sommet = file.pop(0)
        for voisin in Graph._graphe_dict[sommet] :
            if voisin == dest:
                Noeud = sommet
                chemin = [dest]
                while Noeud:
                    chemin.append(Noeud)
                    Noeud = parents[Noeud]
                chemin.reverse()
                return chemin
            elif voisin not in visites:
                file.append(voisin)
                visites.append(voisin)
                parents[voisin] = sommet
    
    return []


def parcours(Graph):
      if Graph.eulerien():
            for start, dest in combinations(Graph, 2):
                print("start ",start,"dest ",dest)
                chem = plusCourtChemin(Graph,start,dest)
                print(chem)
                    
      else:
          print("Ce graph n'est pas eulerien, je ne peux trouver le plus court chemin")

print(parcours(graph2))